#include <stdio.h>

int main() {
	printf("Enter M and N of matrix A: ");
	int m,n;
	int p,q;
	scanf("%i %i",&m,&n);
	printf("Enter matrix elements: ");
	int i,j,matA[101][101];
	for (i=0; i<m; i++)
		for(j=0; j<n; j++){
			scanf("%i",&matA[i][j]);
		}


int temp;
	for (i = 0; i < m; i++)
    {
        for (j = i + 1; j < n; j++)
        {
            temp = matA[i][j];
            matA[i][j] = matA[j][i];
            matA[j][i] = temp;
        }
    }

    for (i = 0; i < m; i++)
    {
        for (j = 0; j < n / 2; j++)
        {
            temp = matA[i][j];
            matA[i][j] = matA[i][n - 1 - j];
            matA[i][n - 1 - j] = temp;
        }
    }



	for (i = 0; i < n; i++)
    {
        for (j = 0; j < n; j++)
            printf("%2d ", matA[i][j]);

        printf("\n");
    }
    printf("\n");








	return 0;
}
