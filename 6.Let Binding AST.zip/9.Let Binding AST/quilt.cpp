#include <iostream>
#include <stdlib.h>
#include <string>
#include <map>
#include <fstream> 
#include <list>
#include <iterator> 
#include "quilt.h"
#define COUNT 4 
int SPACE =0;
int c=0,z=0;
fstream  cfile ("compile.cpp", ios::out), file ("matrix.txt",ios::out), myfile ("ast.txt",ios::out);

using namespace std;

extern symtab m111;
list<char*> FPL;
list<exp_node*> APL;
int symtab_entry::counter = 0;

void A_node:: print() 
{
	remove("compile.cpp");
  remove("matrix.txt");
  myfile << "(A\n";
  for (int i = 0; i < SPACE; i++) 
  myfile<<" "; 
  myfile<<" )\n"; 
}
void B_node:: print() 
{
	remove("compile.cpp");
  remove("matrix.txt");
  myfile << "(B\n";
  for (int i = 0; i < SPACE; i++) 
  myfile<<" "; 
  myfile<<" )\n";  
}
void sew_node:: print() 
{
  myfile << "(";
  myfile << "SEW\n";
  SPACE+= COUNT; 
  for (int i = 0; i < SPACE; i++)  
    myfile<<" "; 
  left->print();
  for (int i = 0; i <= SPACE; i++) 
    myfile<<" ";
        myfile<<",\n";
  for (int i = 0; i < SPACE; i++)  
    myfile<<" "; 
    right->print();
    SPACE-=COUNT;
  for (int i = 0; i < SPACE; i++) 
    myfile<<" ";
    myfile << ")\n";
}

void turn_node:: print() 
{
  
  myfile<< "(";
  myfile<< "TURN \n ";
  SPACE+= COUNT; 
  for (int i = 0; i < SPACE; i++)  
    myfile<<" "; 
    left->print();
    SPACE-=COUNT;
  for (int i = 0; i < SPACE; i++) 
    myfile<<" ";
    myfile<< ")\n";

}
void let_AST:: print() 
{
  myfile<<"\n(LET\n";
  SPACE+= COUNT; 
  for (int i = 0; i < SPACE; i++)  
  myfile<<" "; 
  myfile<<"(DECLS\n";
  SPACE+= COUNT; 
  for (int i = 0; i < SPACE; i++)  
  myfile<<" ";
  dec->print();
  SPACE-=COUNT;
  for (int i = 0; i < SPACE; i++) 
  	myfile<<" ";
 myfile << ")\n";
  
  for (int i = 0; i < SPACE; i++)  
  myfile<<" "; 
  myfile<<",\n";
   
  for (int i = 0; i < SPACE; i++)  
  myfile<<" "; 
 myfile<<"(IN-EXPR\n";
 SPACE+= COUNT; 
  for (int i = 0; i < SPACE; i++)  
    myfile<<" ";
  exp->print();
  SPACE-=COUNT;
  for (int i = 0; i < SPACE; i++) 
  myfile<<" ";
  myfile << ")\n";
  SPACE-=COUNT;
  for (int i = 0; i < SPACE; i++) 
  myfile<<" ";
  myfile << ")\n";

}

void fun_AST::print()
{ 
	myfile<<"(FUN ";
	myfile<<fun_name<<" =\n";
	SPACE+= COUNT; 
  for (int i = 0; i < SPACE; i++)  
  	myfile<<" "; 
  myfile<<"(PARAMS\n";
  SPACE+= COUNT; 
  for (int i = 0; i < SPACE; i++)  
   myfile<<" ";
  myfile<<"(";
  param->print();
  myfile << ")\n";
  SPACE-=COUNT;
  for (int i = 0; i < SPACE; i++) 
   myfile<<" ";
  myfile << ")\n";
  for (int i = 0; i <= SPACE; i++) 
    myfile<<" ";
  myfile<<",\n";
  for (int i = 0; i < SPACE; i++)  
    myfile<<" "; 
  myfile<<"(EXPR\n";
  SPACE+= COUNT; 
  for (int i = 0; i < SPACE; i++)  
    myfile<<" "; 
  fexp->print();
  SPACE-=COUNT;
  for (int i = 0; i < SPACE; i++) 
   myfile<<" ";
  myfile << ")\n";
  SPACE-=COUNT;
  for (int i = 0; i < SPACE; i++) 
  myfile<<" ";
 myfile << ")\n";
}
void val_AST::print()
{
	myfile<<"(VAL "<<val_name<<" =\n";
	SPACE+= COUNT; 
	for (int i = 0; i < SPACE; i++)  
 myfile<<" ";
	vexp->print();

	SPACE-=COUNT;
	for (int i = 0; i < SPACE; i++) 
  	myfile<<" ";
	myfile << ")\n";

}
void call_AST::print()
{     
       
if (para = NULL)
{
	myfile<<"(CALL FUN "<<f_name<<"\n";
	SPACE+= COUNT; 
	for (int i = 0; i < SPACE; i++)  
  	myfile<<" ";
	myfile<<"(ACTUAL PARAM\n";
  SPACE+= COUNT; 
  for (int i = 0; i < SPACE; i++)  
    cout<<" ";
  para->print();
  SPACE-=COUNT;
  for (int i = 0; i < SPACE; i++) 
  	myfile<<" ";
 	myfile << ")\n";
	SPACE-=COUNT;
  for (int i = 0; i < SPACE; i++) 
    myfile<<" ";
  myfile<< ")\n";
}
else
{
	myfile<<"(FORMAl PARAM\n\n";
	SPACE+= COUNT; 
 	for (int i = 0; i < SPACE; i++)  
    myfile<<" ";
	myfile<<f_name<<"\n\n";
	SPACE-= COUNT; 
 	for (int i = 0; i < SPACE; i++)  
    myfile<<" ";
	myfile<<")\n";
}

}

void formal_param_list:: print()
{
	FPL.push_back(f_p_l);
	if (ef_p_l != NULL)
 	{
	myfile<<f_p_l;
	myfile<<",";
	ef_p_l->print();	
	}
	else
	myfile<<f_p_l;
}

void actual_param_list:: print()
{
	APL.push_back(ea_p_l1);
	SPACE+= COUNT; 
	for (int i = 0; i < SPACE; i++)  
  		myfile<<" ";
	ea_p_l1->print();
	if (ea_p_l2 != NULL)
	{
			 SPACE-=COUNT;
			ea_p_l2->print();
	}
}
void decls::print()
{	if (decl2 != NULL)
 	{
	decl1->print();
  for (int i = 0; i < SPACE; i++)  
    myfile<<" ";
	decl2->print();
	}
	else
	decl1->print();
}

matrix A_node:: evalute()
{
  m1.m[0][0]={a0};
  return m1;
}

matrix B_node:: evalute()
{
  m2.m[0][0]={b0};
  return m2;
}


matrix sew_node:: evalute()
{
  m3=left->evalute();
  m4=right->evalute();
  if(m3.rows==m4.rows)
  {
    m5.rows=m3.rows;
    m5.columns=m3.columns+m4.columns+1;
    for(int d=0;d<=m5.rows;d++)
  {
    for(int c=0;c<=m5.columns;c++)
    {
      if(c<=m3.columns)
      m5.m[d][c]=m3.m[d][c];
      else
      m5.m[d][c]=m4.m[d][c-m3.columns-1];
    }
  }
  return m5;
  }
  else 
    cout<<"can't sew\n";
}


matrix turn_node:: evalute() 
{
  m6=left->evalute();
  for(int c=0;c<=m6.rows;c++)
  {
      for(int d=0;d<=m6.columns;d++)
      {
          if(m6.m[c][d]==a0)
          m6.m[c][d]=a1;
          else if(m6.m[c][d]==a1)
                m6.m[c][d]=a2;
          else if(m6.m[c][d]==a2)
          m6.m[c][d]=a3;
          else if(m6.m[c][d]==a3)
          m6.m[c][d]=a0;
          else if(m6.m[c][d]==b0)
          m6.m[c][d]=b1;
          else if(m6.m[c][d]==b1)
          m6.m[c][d]=b2;
          else if(m6.m[c][d]==b2)
          m6.m[c][d]=b3;
          else if(m6.m[c][d]==b3)
          m6.m[c][d]=b0;
      }
  }

  int p=0,q=0,temp;
  for(int i=0;i<=m6.columns;i++)
  {
    for(int j=m6.rows;j>=0;j--)
    {
      m7.m[p][q]=m6.m[j][i];
      q++;
    }
      p++;q=0;
  }
  for(int i=0;i<=m6.columns;i++)
  {
    for(int j=0;j<=m6.rows;j++)
    {
      m6.m[i][j]=m7.m[i][j];
    }
  }
  temp=m6.rows;
  m6.rows=m6.columns;
  m6.columns=temp;
  return m6;
}

matrix let_AST:: evalute() 
{

	m21=exp->evalute();
	return m21;
}

matrix fun_AST:: evalute() 
{	

 	matrix n;
 	return n; //nouse
}

matrix val_AST :: evalute()  
{

  m29=vexp->evalute();
  return m29;

}

matrix call_AST:: evalute() 
{

  list <char*> :: iterator it; 
  
  val=m111.find(f_name);

  m23=val->evalute();
	return m23;
  m93=para->evalute();
  	return m93;
}

matrix formal_param_list:: evalute() 
{
	matrix n;
 	return n; //nouse
}

matrix actual_param_list:: evalute() 
{
	m24=ea_p_l1->evalute();
	m25=ea_p_l2->evalute();
	return m24,m25;
}

matrix decls:: evalute() 
{
	m41=decl1->evalute();
	return m41; 
	m41=decl1->evalute();
 	return m42; 
}

 
void exp_node:: mprint()
{
	remove("compile.cpp");
  remove("ast.txt");
  matrix M=evalute();
  file<<"ROW="<<M.rows+1<<endl;
  file<<"COLUMN="<<M.columns+1<<endl;
  for(int a=0;a<=M.rows;a++)
  {
      for(int b=0;b<=M.columns;b++)
      {
    switch(M.m[a][b])
    { 
      case 0: file<<"a0";
      break;
      case 1: file<<"a1";
      break;
      case 2: file<<"a2";
      break;
      case 3: file<<"a3";
      break;
      case 4: file<<"b0";
      break;
      case 5:file<<"b1";
      break;
      case 6: file<<"b2";
      break;
      case 7: file<<"b3";
      break;
      default:file<<"Not recognize"<<endl;
    }
      
    }
        file<<endl;
   }
}


intcode A_node:: result()
{
o1.op1="a0";
cfile<<"\tQuilt t"<<z<<" = "<<"Quilt ("<<o1.op1<<");"<<endl;
o1.parse += std::to_string(z);
z++;
return o1;
}

//---------------------------------------------------------------RESULT B-NODE---------------------------------------------------------------//
intcode B_node:: result() 
{
o2.op1="b0";
cfile<<"\tQuilt t"<<z<<" = "<<"Quilt ("<<o2.op1<<");"<<endl;
o2.parse += std::to_string(z);
z++;
return o2;
}

//-------------------------------------------------------------RESULT SEW-NODE---------------------------------------------------------------//
intcode sew_node:: result() 
{
o3=left->result();
o4=right->result();

o5.op1=o3.parse;
o5.op2=o4.parse;
cfile<<"\tQuilt t"<<z<<" = sew"<<"("<<"t"<<o5.op1<<","<<"t"<<o5.op2<<");"<<endl;
o5.parse += std::to_string(z);
z++;
return o5;
}
//-----------------------------------------------------------RESULT TURN-NODE---------------------------------------------------------------//
intcode turn_node:: result() 
{
o6=left->result();
o7.op1=o6.parse;
cfile<<"\tQuilt t"<<z<<" = turn"<<"("<<"t"<<o7.op1<<");"<<endl;
o7.parse += std::to_string(z);
z++;
return o7;

}

intcode let_AST:: result() 
{	
	o31=dec->result();
  cfile<<"\nint main"<<endl;
  cfile<<"{ \n";
   o21=exp->result();
   z--;
  cfile<<"\tt"<<z<<".print-quilt.cout() \n";
  cfile<<"}"<<endl;
   return o31,o21;
}
intcode fun_AST:: result() 
{
	o33=param->result();
	o34=fexp->result();
	return o33,o34;
}
intcode val_AST:: result() 
{
	c=c+1;
	cfile<<"\nQuilt "<<val_name<<"()"<<"\n {\n";
	o29=vexp->result();
	z--;
    cfile<<"\treturn t"<<z<<endl;
    cfile<<"}\n";
    z++;
	return o29;

}
intcode  call_AST:: result() 
{
  //cfile<<"int main"<<endl;
 // cfile<<"{ \n";
  cfile<<"\tQuilt t"<<z<<" = "<<f_name<<"()"<<"\n ";
 // cfile<<"t"<<z<<".print-quilt.cout() \n";
 // cfile<<"}"<<endl;
   z++;
  return o23; 
}
intcode formal_param_list:: result() 
{
	o32=ef_p_l->result();
	return o32;
}
intcode actual_param_list:: result() 
{
	o24=ea_p_l1->result();
	return o24;
	o25=ea_p_l2->result();
	return o25;
}
intcode decls:: result() 
{
	if (decl2 != NULL)
  {
  decl1->result();
  decl2->result();
  }
  else
  decl1->result();

}

//-----------------------------------------------------------CPRINT FUNCTION-----------------------------------------------------------------//
void exp_node:: cprint()
{
  remove("ast.txt");
  remove("matrix.txt");
  intcode Q=result();
}


void exp_node:: help()
{
remove("ast.txt");
remove("matrix.txt");
remove("compile.cpp");
cout<<"Usage: quilt [options] [file]"<<endl;
cout<<"\t\t\toptions:"<<endl;
cout<<"\t\t\t-help:\tShow the help"<<endl;
cout<<"\t\t\t-ast:\tshow abstract syntax tree in ast.txt"<<endl;
cout<<"\t\t\t-cpp:\tcompile the program and generate the c++ file compile.cpp"<<endl;
cout<<"\t\t\t-matrix:\tInterperate  the program and generate the matrix file matrix.txt"<<endl;
}

/*int symtab::hashf(string id) 
{ 
    int asciiSum = 0; 
  
    for (int i = 0; i < id.length(); i++) { 
        asciiSum = asciiSum + id[i]; 
    } 
  
    return (asciiSum % 50); 
} 

bool symtab :: insert (string id, int position, exp_node *ast)
{
	int index =hashf(id);
	symtab *p=new symtab_entry(name, position, *ast);
	if (head[index]== NULL)
	{
		head[index]=p;
		return true;
	}
	else
	{
		symtab_entry* start = head[index]; 
        while (start->next != NULL) 
            start = start->next; 
  
        start->next = p; 
        return true;
	}
	return false;
}


/*string symtab ::find(string id) 
{ 
    int index = hashf(id); 
    symtab_entry* start = head[index]; 
  
    if (start == NULL) 
        return "-1"; 
  
    /*while (start != NULL) 
    { 
  
        if (start->name == id) 
        { 
            return start->scope; 
        } 
  
        start = start->next; 
    } */
  
    //return "-1";
//}



