#include <iostream>
#include <stdlib.h>
#include <string>
#include <cstring>
#include <map>
#include <fstream>
#include <list>
#include <stack>

using namespace std;
enum var {a0,a1,a2,a3,b0,b1,b2,b3};

class intcode
{
public:
string op;
string op1;
string op2;
string parse;
};

class matrix
{
public:
int rows;
int columns;
var m[50][50]; 
};

class exp_node : public matrix, public intcode
{
public:
virtual void print() = 0;
virtual matrix evalute()= 0;
virtual intcode result() = 0;
void cprint();
void mprint();
void help();
};

class symtab_entry : public exp_node 
{
public:
static int counter;
int id;
char* name;
int position;
exp_node *ast;
symtab_entry *next;
symtab_entry()
{
	next=NULL;
}
symtab_entry(char* e_n, int e_p, exp_node *e_ast)
{
	name=e_n;
	position=e_p;
	ast=e_ast;
	next=NULL;
}
void print(){}
matrix evalute(){matrix n; return n;}
intcode result() {}
};

class symtab :  public symtab_entry
{
	public:
	symtab_entry *head, *tail;
	symtab()
	{
		head=NULL;
		tail=NULL;
	}
	void add_node(char* e_n, int e_p, exp_node *e_a)
	{
		symtab_entry *tmp = new symtab_entry();
		
		tmp->name=e_n;
		tmp->position=e_p;
		tmp->ast=e_a;
		tmp->id = symtab_entry::counter++;
		symtab_entry::counter = symtab_entry::counter + 1;
		tmp->next=NULL;
		if(head== NULL)
		{
			head=tmp;
			tail=tmp;
		} 
		else
		{
			tail->next=tmp;
			tail=tail->next;
		}
	}
	exp_node* find( char* e_n)
	{
		symtab_entry *current =head;
		while(current!=NULL)
		{
			if(strcmp(current->name,e_n) == 0)
			{
				return current->ast;
			}
			else
				current=current->next;
		}

	}

	int findId(char *name)
	{
		symtab_entry *current =head;
		
		while(current!=NULL)
		{
			if(strcmp(current->name,name) == 0)
			{
				return current->id;
			}
			else
				current=current->next;
		}	
	}

void print() {}
matrix evalute() {matrix n; return n;}
intcode result() {}
};

class A_node : public exp_node 
{
public:
void print(); 
matrix evalute();
intcode result();
matrix m1;
intcode o1;
};

class B_node : public exp_node 
{
public:
void print();
matrix evalute();
intcode result();
matrix m2;
intcode o2;
};


class sew_node : public exp_node 
{
exp_node *left;
exp_node *right;
public:
sew_node(exp_node *l, exp_node *r)
{
	left = l;
	right = r;
}
matrix evalute();
void print();
intcode result();
matrix m3,m4,m5;
intcode o4,o5,o3;
};


class turn_node : public exp_node 
{
exp_node *left;
public:
turn_node(exp_node *l)
{
	left = l;
}
void print();
matrix evalute();
intcode result();
matrix m6,m7;
intcode o6,o7;
};

class let_AST :public exp_node
{
public:
exp_node *dec;
exp_node *exp;
let_AST(exp_node *D, exp_node *E)
{
	dec = D;
	exp = E;
}
void print();
matrix evalute();
intcode result();
matrix m21,m31;
intcode o21,o31;
};

class fun_AST :public exp_node
{
public:
char* fun_name;
exp_node *param;
exp_node *fexp;
fun_AST(char* f_n,exp_node *P, exp_node *EX)
{
	fun_name=f_n;
	param = P;
	fexp = EX;
}
void print();
intcode result();
matrix evalute();
intcode o33,o34;
};

class val_AST : public exp_node
{
public:
char* val_name;
exp_node *vexp;
val_AST(char* val, exp_node *EXP)
{
	val_name=val;
	vexp = EXP;
}
void print();
matrix evalute();
intcode result();
matrix m29;
intcode o29;
//exp_node* val;
//symtab m111;
};

class formal_param_list : public exp_node
{
public:
char* f_p_l;
exp_node *ef_p_l;
formal_param_list(char* f_p, exp_node *exf_p_l)
{
	f_p_l=f_p;
	ef_p_l=exf_p_l;
}
void print();
matrix evalute();
intcode result();
intcode o32;
};

class call_AST : public exp_node
{
public:
char* f_name;
exp_node *para;
call_AST(char* cf_n, exp_node *ex_para)
{
	f_name=cf_n;
	para=ex_para;
}
void print();
matrix evalute();
intcode result();
matrix m23,m93;
intcode o23,o93;
exp_node* val;
//symtab m112;
};
class actual_param_list : public exp_node
{
public:
exp_node *ea_p_l1;
exp_node *ea_p_l2;
actual_param_list(exp_node *exa_p_l1, exp_node *exa_p_l2)
{
	ea_p_l1=exa_p_l1;
	ea_p_l2=exa_p_l2;
}
void print();
matrix evalute();
intcode result();
matrix m24,m25;
intcode o24,o25;
};

class decls : public exp_node
{
public:
exp_node *decl1;
exp_node *decl2;
decls(exp_node *edecl1, exp_node *edecl2)
{
	decl1=edecl1;
	decl2=edecl2;
}
void print();
matrix evalute();
intcode result();
matrix m41,m42;
intcode o41,o42;
};

