//-----------------------------------------------------------------------------------------------------------------------------------------//

#include <iostream>
#include <stdlib.h>
#include <string>
#include <fstream>
#include <map>
#include <list>
enum var {a0,a1,a2,a3,b0,b1,b2,b3};
using namespace std;

//---------------------------------------------------------------INTCODE CLASS-------------------------------------------------------------//
class intcode
{
public:
string op;
string op1;
string op2;
string parse;
};
//---------------------------------------------------------------MATRIX CLASS-------------------------------------------------------------//
class matrix
{
public:
int rows;
int columns;
var m[50][50]; 
};

//---------------------------------------------------------------EXP CLASS----------------------------------------------------------------//
class exp_node : public matrix, public intcode
{
public:
virtual void print() = 0;
virtual void token() = 0;
virtual matrix evalute() = 0;
virtual intcode result() = 0;
void mprint();
void cprint();
void help();
};

//---------------------------------------------------------------A-NODE CLASS---------------------------------------------------------------//
class A_node : public exp_node
{
public:
void print();
void token();
matrix evalute();
intcode result();
matrix m1;
intcode o1;
};

//---------------------------------------------------------------B-NODE CLASS---------------------------------------------------------------//
class B_node : public exp_node
{
public:
void print();
void token();
matrix evalute();
intcode result();
matrix m2;
intcode o2;
};

//---------------------------------------------------------------SEW NODE CLASS-------------------------------------------------------------//
class sew_node : public exp_node
{
exp_node *left;
exp_node *right;
public:
sew_node(exp_node *l, exp_node *r)
{
	left = l;
	right = r;
}

void print();
void token();
matrix evalute();
intcode result();
matrix m4,m5,m3;
intcode o4,o5,o3;
};

//---------------------------------------------------------------TURN NODE CLASS-------------------------------------------------------------//
class turn_node : public exp_node
{
exp_node *left;
public:
turn_node(exp_node *l)
{
	left = l;
}
void print();
void token();
matrix evalute();
intcode result();
matrix m6,m7;
intcode o6,o7;
};

//------------------------------------------------------------------------------------------------------------------------------------------//
