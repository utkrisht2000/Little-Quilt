//-------------------------------------------------------------------------------------------------------------------------------------------//

#include <iostream>
#include <stdlib.h>
#include <string.h>
#include <fstream> 
#include <map>
#include <list>
#include "quilt.h"
#define COUNT 4    
int SPACE =0;
int z=0;
fstream file, cfile, myfile ("ast.txt",ios::out),tfile("out.toks",ios::out);


//---------------------------------------------------------------PRINT FUNCTIONS-------------------------------------------------------------//
//----------------------------------------------------------------PRINT A-NODE---------------------------------------------------------------//
void A_node:: print()
{
  remove("out.toks");
  remove("compile.cpp");
  remove("matrix.txt");
  myfile << "(A\n";
  for (int i = 0; i < SPACE; i++) 
  myfile<<" "; 
  myfile<<" )\n";
}

//----------------------------------------------------------------PRINT B-NODE---------------------------------------------------------------//
void B_node:: print() 
{
  remove("out.toks");
  remove("compile.cpp");
  remove("matrix.txt");
  myfile << "(B\n";
  for (int i = 0; i < SPACE; i++) 
  myfile<<" "; 
  myfile<<" )\n"; 
}

//--------------------------------------------------------------PRINT SEW-NODE---------------------------------------------------------------//
void sew_node:: print() 
{
  myfile << "(";
  myfile << "SEW\n";
  SPACE+= COUNT; 
  for (int i = 0; i < SPACE; i++)  
  	myfile<<" "; 
 	left->print();
  for (int i = 0; i <= SPACE; i++) 
  	myfile<<" ";
        myfile<<",\n";
  for (int i = 0; i < SPACE; i++)  
  	myfile<<" "; 
  	right->print();
  	SPACE-=COUNT;
  for (int i = 0; i < SPACE; i++) 
  	myfile<<" ";
  	myfile << ")\n";
}
//-------------------------------------------------------------PRINT TURN-NODE---------------------------------------------------------------//
void turn_node:: print() 
{
  myfile<< "(";
  myfile<< "TURN \n ";
  SPACE+= COUNT; 
  for (int i = 0; i < SPACE; i++)  
  	myfile<<" "; 
  	left->print();
  	SPACE-=COUNT;
  for (int i = 0; i < SPACE; i++) 
  	myfile<<" ";
  	myfile<< ")\n";
}

//----------------------------------------------------------EVALUATE FUNCTIONS--------------------------------------------------------------//
//------------------------------------------------------------EVALUATE A-NODE---------------------------------------------------------------//
matrix A_node:: evalute()
{
  m1.m[0][0]={a0};
  return m1;
}

//------------------------------------------------------------EVALUATE B-NODE---------------------------------------------------------------//
matrix B_node:: evalute()
{
  m2.m[0][0]={b0};
  return m2;
}

//-----------------------------------------------------------EVALUATE SEW-NODE---------------------------------------------------------------//
matrix sew_node:: evalute()
{
  m3=left->evalute();
  m4=right->evalute();
  if(m3.rows==m4.rows)
  {
  	m5.rows=m3.rows;
  	m5.columns=m3.columns+m4.columns+1;
  	for(int d=0;d<=m5.rows;d++)
	{
		for(int c=0;c<=m5.columns;c++)
		{
			if(c<=m3.columns)
			m5.m[d][c]=m3.m[d][c];
                    	else
			m5.m[d][c]=m4.m[d][c-m3.columns-1];
		}
	}
  return m5;, myfile ("ast.txt",ios::out);

  }
  else 
  	cout<<"can't sew\n";
}
//----------------------------------------------------------EVALUATE TURN-NODE---------------------------------------------------------------//
matrix turn_node:: evalute() 
{
  m6=left->evalute();
  for(int c=0;c<=m6.rows;c++)
  {
    	for(int d=0;d<=m6.columns;d++)
    	{
      		if(m6.m[c][d]==a0)
       		m6.m[c][d]=a1;
      		else if(m6.m[c][d]==a1)
      	        m6.m[c][d]=a2;
      		else if(m6.m[c][d]==a2)
       		m6.m[c][d]=a3;
      		else if(m6.m[c][d]==a3)
       		m6.m[c][d]=a0;
      		else if(m6.m[c][d]==b0)
       		m6.m[c][d]=b1;
      		else if(m6.m[c][d]==b1)
       		m6.m[c][d]=b2;
      		else if(m6.m[c][d]==b2)
       		m6.m[c][d]=b3;
      		else if(m6.m[c][d]==b3)
       		m6.m[c][d]=b0;
    	}
  }
//-----------------------------------------------------------MATRIX_ROTATION-------------------------------------------------------------//
  int p=0,q=0,temp;
  for(int i=0;i<=m6.columns;i++)
  {
  	for(int j=m6.rows;j>=0;j--)
  	{
  		m7.m[p][q]=m6.m[j][i];
   		q++;
   	}
    	p++;q=0;
  }
  for(int i=0;i<=m6.columns;i++)
  {
  	for(int j=0;j<=m6.rows;j++)
  	{
   		m6.m[i][j]=m7.m[i][j];
  	}
  }
  temp=m6.rows;
  m6.rows=m6.columns;
  m6.columns=temp;
  return m6;
}


//-----------------------------------------------------------MPRINT FUNCTION-----------------------------------------------------------------//
void exp_node:: mprint()
{
  remove("out.toks");
  remove("ast.txt");
  remove("compile.cpp");
  file.open("matrix.txt",ios::out);
  matrix M=evalute();
  file<<"ROW="<<M.rows+1<<endl;
  file<<"COLUMN="<<M.columns+1<<endl;
  for(int a=0;a<=M.rows;a++)
  {
    	for(int b=0;b<=M.columns;b++)
    	{
		switch(M.m[a][b])
		{	
			case 0: file<<"a0";
			break;
			case 1: file<<"a1";
			break;
			case 2: file<<"a2";
			break;
			case 3: file<<"a3";
			break;
			case 4: file<<"b0";
			break;
			case 5:file<<"b1";
			break;
			case 6: file<<"b2";
			break;
			case 7: file<<"b3";
			break;
			default:file<<"Not recognize"<<endl;
		}
			
   	}
        file<<endl;
   }
}

//-------------------------------------------------------------RESULT FUNCTIONS-------------------------------------------------------------//
//--------------------------------------------------------------RESULT A-NODE---------------------------------------------------------------//

intcode A_node:: result()
{
o1.op1="a0";
cfile<<"Quilt t"<<z<<" = "<<"Quilt "<<o1.op1<<endl;
o1.parse += std::to_string(z);
z++;
return o1;
}

//---------------------------------------------------------------RESULT B-NODE---------------------------------------------------------------//
intcode B_node:: result() 
{
o2.op1="b0";
cfile<<"Quilt t"<<z<<" = "<<"Quilt "<<o2.op1<<endl;
o2.parse += std::to_string(z);
z++;
return o2;
}

//-------------------------------------------------------------RESULT SEW-NODE---------------------------------------------------------------//
intcode sew_node:: result() 
{
o3=left->result();
o4=right->result();

o5.op1=o3.parse;
o5.op2=o4.parse;
cfile<<"Quilt t"<<z<<" = sew"<<"("<<"t"<<o5.op1<<","<<"t"<<o5.op2<<")"<<endl;
o5.parse += std::to_string(z);
z++;
return o5;
}
//-----------------------------------------------------------RESULT TURN-NODE---------------------------------------------------------------//
intcode turn_node:: result() 
{
o6=left->result();

o7.op1=o6.parse;
cfile<<"Quilt t"<<z<<" = turn"<<"("<<"t"<<o7.op1<<")"<<endl;
o7.parse += std::to_string(z);
z++;
return o7;

}

//-----------------------------------------------------------CPRINT FUNCTION-----------------------------------------------------------------//
void exp_node:: cprint()
{
  remove("out.toks");
  remove("ast.txt");
  remove("matrix.txt");
  cfile.open("compile.cpp", ios::out);
  cfile<<"int main"<<endl;
  cfile<<"{ \n"<<endl;
  intcode Q=result();
  z--;
  cfile<<"\nt"<<z<<".print-quilt.cout() \n"<<endl;
  cfile<<"}"<<endl;
}
//------------------------------------------------------------- TOKEN FUNCTIONS-------------------------------------------------------------//
//--------------------------------------------------------------TOKEN A-NODE---------------------------------------------------------------//

void A_node:: token()
{
remove("ast.txt");
remove("compile.cpp");
remove("matrix.txt");
tfile<<"\tToken Name: A\t\t"<<"Token: a\t"<<"line no: 1"<<endl;
}

//---------------------------------------------------------------TOKEN B-NODE---------------------------------------------------------------//
void B_node:: token() 
{
remove("ast.txt");
remove("compile.cpp");
remove("matrix.txt");
tfile<<"\tToken Name: B\t\t"<<"Token: b\t"<<"line no: 1"<<endl;
}

//-------------------------------------------------------------TOKEN SEW-NODE---------------------------------------------------------------//
void sew_node:: token() 
{
tfile<<"\tToken Name: SEW\t\t"<<"Token: sew\t"<<"line no: 1"<<endl;
tfile<<"\tToken Name: \'(\'\t\t" <<"Token: (\t"<<"line no: 1"<<endl;
left->token();
tfile<<"\tToken Name: \',\'\t\t"<<"Token: ,\t"<<"line no: 1"<<endl;
right->token();
tfile<<"\tToken Name: \')\'\t\t"<<"Token: )\t"<<"line no: 1"<<endl;
}
//-----------------------------------------------------------TOKEN TURN-NODE---------------------------------------------------------------//
void turn_node:: token() 
{
tfile<<"\tToken Name: TURN\t\t"<<"Token: turn\t"<<"line no: 1"<<endl;
tfile<<"\tToken Name: \'(\'\t\t" <<"Token: (\t"<<"line no: 1"<<endl;
left->token();
tfile<<"\tToken Name: \')\'\t\t"<<"Token: )\t"<<"line no: 1"<<endl;
}
//----------------------------------------------------------HELP FUNCTION-----------------------------------------------------------------//
void exp_node:: help()
{
remove("out.toks");
remove("ast.txt");
remove("matrix.txt");
remove("compile.cpp");
cout<<"Usage: quilt [options] [file]"<<endl;
cout<<"\t\t\toptions:"<<endl;
cout<<"\t\t\t-help:\tShow the help"<<endl;
cout<<"\t\t\t-token:\tShow the tokens in file out.toks"<<endl;
cout<<"\t\t\t-cpp:\tcompile the program and generate the c++ file compile.cpp"<<endl;
cout<<"\t\t\t-ast:\tshow abstract syntax tree in ast.txt"<<endl;
cout<<"\t\t\t-matrix:\tInterperate  the program and generate the matrix file matrix.txt"<<endl;
}










