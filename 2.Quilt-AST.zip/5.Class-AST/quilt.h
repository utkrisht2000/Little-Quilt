#include <iostream>
#include <stdlib.h>
#include <string>
#include <map>
#include <list>

using namespace std;

class exp_node 
{
public:
virtual void print() = 0;
};

class A_node : public exp_node 
{
public:
void print();
};

class B_node : public exp_node 
{
public:
void print();
};


class sew_node : public exp_node 
{
exp_node *left;
exp_node *right;
public:
sew_node(exp_node *l, exp_node *r)
{
	left = l;
	right = r;
}
void print();
};


class turn_node : public exp_node 
{
exp_node *left;
public:
turn_node(exp_node *l)
{
	left = l;
}
void print();
};



