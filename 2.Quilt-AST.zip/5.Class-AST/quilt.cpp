#include <iostream>
#include <stdlib.h>
#include <string>
#include <map>
#include <list>
#include "quilt.h"
#define COUNT 4
int SPACE =0;

using namespace std;

void A_node:: print() 
{
  cout << "(A\n";
  for (int i = 0; i < SPACE; i++) 
  cout<<" "; 
  cout<<" )\n";  
}

void B_node:: print() 
{
  cout << "(B\n";
  for (int i = 0; i < SPACE; i++) 
  cout<<" "; 
  cout<<" )\n";  
}


void sew_node:: print() 
{
  cout << "(";
  cout << "SEW\n";

  SPACE+= COUNT; 
  for (int i = 0; i < SPACE; i++)  
  cout<<" "; 
  left->print();

  for (int i = 0; i <= SPACE; i++) 
  cout<<" ";
  cout<<",\n";
  for (int i = 0; i < SPACE; i++)  
  cout<<" "; 
  right->print();

  SPACE-=COUNT;
  for (int i = 0; i < SPACE; i++) 
  cout<<" ";
  cout << ")\n";
}

void turn_node:: print() 
{
  
  cout << "(";
  cout << "TURN \n ";
  SPACE+= COUNT; 
  for (int i = 0; i < SPACE; i++)  
  cout<<" "; 
  
  left->print();
  SPACE-=COUNT;
  for (int i = 0; i < SPACE; i++) 
  cout<<" ";
  cout << ")\n";

}
