//-------------------------------------------------------------------------------------------------------------------------------------------//

#include <iostream>
#include <stdlib.h>
#include <string.h>
#include <map>
#include <list>
#include "quilt.h"
#define COUNT 4    
int i,j,SPACE =0;
using namespace std;

//---------------------------------------------------------------PRINT FUNCTIONS-------------------------------------------------------------//
//----------------------------------------------------------------PRINT A-NODE---------------------------------------------------------------//
void A_node:: print()
{
  cout << "(A\n";
  for (int i = 0; i < SPACE; i++) 
  cout<<" "; 
  cout<<" )\n";  
}

//----------------------------------------------------------------PRINT B-NODE---------------------------------------------------------------//
void B_node:: print() 
{
  cout << "(B\n";
  for (int i = 0; i < SPACE; i++) 
  cout<<" "; 
  cout<<" )\n"; 
}

//--------------------------------------------------------------PRINT SEW-NODE---------------------------------------------------------------//
void sew_node:: print() 
{
  cout << "(";
  cout << "SEW\n";
  SPACE+= COUNT; 
  for (int i = 0; i < SPACE; i++)  
  	cout<<" "; 
 	left->print();
  for (int i = 0; i <= SPACE; i++) 
  	cout<<" ";
        cout<<",\n";
  for (int i = 0; i < SPACE; i++)  
  	cout<<" "; 
  	right->print();
  	SPACE-=COUNT;
  for (int i = 0; i < SPACE; i++) 
  	cout<<" ";
  	cout << ")\n";
}
//-------------------------------------------------------------PRINT TURN-NODE---------------------------------------------------------------//
void turn_node:: print() 
{
  cout << "(";
  cout << "TURN \n ";
  SPACE+= COUNT; 
  for (int i = 0; i < SPACE; i++)  
  	cout<<" "; 
  	left->print();
  	SPACE-=COUNT;
  for (int i = 0; i < SPACE; i++) 
  	cout<<" ";
  	cout << ")\n";
}
//-------------------------------------------------------------LEVEL 1-----------------------------------------------------------------------//
//------------------------------------------------------------PRINT HDROW-NODE--------------------------------------------------------------// 
void hdrow_node:: print()
{
  cout << "(hdRow\n";
  SPACE+= COUNT; 
  for (int i = 0; i < SPACE; i++)  
  	cout<<" "; 
  	left->print();
  	SPACE-=COUNT;
  for (int i = 0; i < SPACE; i++) 
  	cout<<" ";
  	cout << ")\n"; 
}
//------------------------------------------------------------PRINT HDCOL-NODE--------------------------------------------------------------//
void hdcol_node:: print()
{
  cout << "(hdCol\n";
  SPACE+= COUNT; 
  for (int i = 0; i < SPACE; i++)  
  	cout<<" "; 
  	left->print();
  	SPACE-=COUNT;
  for (int i = 0; i < SPACE; i++) 
  	cout<<" ";
  	cout << ")\n"; 
}
//------------------------------------------------------------PRINT TLROW-NODE--------------------------------------------------------------//
void tlrow_node:: print()
{
  cout << "(tlRow\n";
  SPACE+= COUNT; 
  for (int i = 0; i < SPACE; i++)  
  	cout<<" "; 
  	left->print();
  	SPACE-=COUNT;
  for (int i = 0; i < SPACE; i++) 
  	cout<<" ";
  	cout << ")\n";  
}
//------------------------------------------------------------PRINT TLCOL-NODE--------------------------------------------------------------//
void tlcol_node:: print()
{
  cout << "(tlCOl\n";
  SPACE+= COUNT; 
  for (int i = 0; i < SPACE; i++)  
  	cout<<" "; 
  	left->print();
  	SPACE-=COUNT;
  for (int i = 0; i < SPACE; i++) 
  	cout<<" ";
  	cout << ")\n"; 
}

//----------------------------------------------------------EVALUATE FUNCTIONS--------------------------------------------------------------//
//------------------------------------------------------------EVALUATE A-NODE---------------------------------------------------------------//
matrix A_node:: evalute()
{
  m1.m[0][0]={a0};
  return m1;
}

//------------------------------------------------------------EVALUATE B-NODE---------------------------------------------------------------//
matrix B_node:: evalute()
{
  m2.m[0][0]={b0};
  return m2;
}

//-----------------------------------------------------------EVALUATE SEW-NODE---------------------------------------------------------------//
matrix sew_node:: evalute()
{
  m3=left->evalute();
  m4=right->evalute();
  if(m3.rows==m4.rows)
  {
  	m5.rows=m3.rows;
  	m5.columns=m3.columns+m4.columns+1;
  	for(int d=0;d<=m5.rows;d++)
	{
		for(int c=0;c<=m5.columns;c++)
		{
			if(c<=m3.columns)
			m5.m[d][c]=m3.m[d][c];
                    	else
			m5.m[d][c]=m4.m[d][c-m3.columns-1];
		}
	}
  return m5;
  }
  else 
  	cout<<"can't sew\n";
}

//----------------------------------------------------------EVALUATE TURN-NODE---------------------------------------------------------------//
matrix turn_node:: evalute() 
{
  m6=left->evalute();
  for(int c=0;c<=m6.rows;c++)
  {
    	for(int d=0;d<=m6.columns;d++)
    	{
      		if(m6.m[c][d]==a0)
       		m6.m[c][d]=a1;
      		else if(m6.m[c][d]==a1)
      	        m6.m[c][d]=a2;
      		else if(m6.m[c][d]==a2)
       		m6.m[c][d]=a3;
      		else if(m6.m[c][d]==a3)
       		m6.m[c][d]=a0;
      		else if(m6.m[c][d]==b0)
       		m6.m[c][d]=b1;
      		else if(m6.m[c][d]==b1)
       		m6.m[c][d]=b2;
      		else if(m6.m[c][d]==b2)
       		m6.m[c][d]=b3;
      		else if(m6.m[c][d]==b3)
       		m6.m[c][d]=b0;
    	}
  }
//-----------------------------------------------------------MATRIX_ROTATION-------------------------------------------------------------//
  int p=0,q=0,temp;
  for(int i=0;i<=m6.columns;i++)
  {
  	for(int j=m6.rows;j>=0;j--)
  	{
  		m7.m[p][q]=m6.m[j][i];
   		q++;
   	}
    	p++;q=0;
  }
  for(int i=0;i<=m6.columns;i++)
  {
  	for(int j=0;j<=m6.rows;j++)
  	{
   		m6.m[i][j]=m7.m[i][j];
  	}
  }
  temp=m6.rows;
  m6.rows=m6.columns;
  m6.columns=temp;
  return m6;
}
//-------------------------------------------------------------LEVEL 1-----------------------------------------------------------------------//
//----------------------------------------------------------EVALUATE HDROW-NODE--------------------------------------------------------------//
matrix hdrow_node:: evalute() 
{
  m8=left->evalute();
  for(int c=0;c<=0;c++)
  {
    	for(int d=0;d<=m8.columns;d++)
    	{
    	  m9.m[i][j]=m8.m[i][j];
  	}
  }
  return m9;
}
//----------------------------------------------------------EVALUATE HDCOL-NODE--------------------------------------------------------------//
matrix hdcol_node:: evalute() 
{
  m10=left->evalute();
  for(int c=0;c<=m10.rows;c++)
  {
    	for(int d=0;d<=0;d++)
    	{
    	  m11.m[i][j]=m10.m[i][j];
  	}
  }
  return m11;
}
//----------------------------------------------------------EVALUATE TLROW-NODE--------------------------------------------------------------//
matrix tlrow_node:: evalute() 
{
  m12=left->evalute();
  for(int c=1;c<=m12.rows;c++)
  {
    	for(int d=0;d<=m12.columns;d++)
    	{
    	  m13.m[i-1][j]=m12.m[i][j];
  	}
  }
  return m13;
}
//-----------------------------------------------------------EVALUATE TLCOL-NODE-------------------------------------------------------------//
matrix tlcol_node:: evalute() 
{
  m14=left->evalute();
  for(int c=0;c<=m14.rows;c++)
  {
    	for(int d=1;d<=m14.columns;d++)
    	{
    	  m15.m[i][j-0]=m14.m[i][j];
  	}
  }
  return m15;
}

//-----------------------------------------------------------MPRINT FUNCTION-----------------------------------------------------------------//
void exp_node:: mprint()
{
  matrix M=evalute();
  cout<<"ROW="<<M.rows+1<<endl;
  cout<<"COLUMN="<<M.columns+1<<endl;
  for(int a=0;a<=M.rows;a++)
  {
    	for(int b=0;b<=M.columns;b++)
    	{
		switch(M.m[a][b])
		{	
			case 0: cout<<"a0";
			break;
			case 1: cout<<"a1";
			break;
			case 2: cout<<"a2";
			break;
			case 3: cout<<"a3";
			break;
			case 4: cout<<"b0";
			break;
			case 5: cout<<"b1";
			break;
			case 6: cout<<"b2";
			break;
			case 7: cout<<"b3";
			break;
			default: cout<<"Not recognize"<<endl;
		}
			
   	}
        cout<<endl;
   }
}
